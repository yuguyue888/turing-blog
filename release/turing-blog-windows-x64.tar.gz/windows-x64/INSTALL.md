# 图灵花园 - 安装说明

## 系统要求
- 操作系统: Windows 10/11 (64位)
- 内存: 最低 512MB
- 磁盘: 最低 100MB
- Node.js: 20.19+ (推荐 22.x)

## 安装步骤

### 方法1：一键启动（推荐）

1. 解压 `turing-blog-windows-x64.zip` 到任意目录
2. 双击 `start-server.bat`
3. 浏览器自动打开: http://localhost:5173

### 方法2：手动启动

1. 安装 Node.js (如果没有)
   - 下载: https://nodejs.org/
   - 选择 LTS 版本 (22.x)
   - 安装时勾选 "Add to PATH"

2. 解压文件

3. 打开 PowerShell 或 CMD
   ```powershell
   cd turing-blog
   npm install --production
   node server.js
   ```

4. 访问: http://localhost:5173

## 后台管理

- 地址: http://localhost:5173/#/admin
- 用户名: admin
- 密码: admin123

⚠️ **请立即修改默认密码！**

## 防火墙配置

```powershell
# 开放端口 5173 和 3001
New-NetFirewallRule -DisplayName "Turing Blog" -Direction Inbound -LocalPort 5173,3001 -Protocol TCP -Action Allow
```

## 开机自启

### 方法1：任务计划程序

1. Win + R → 输入 `taskschd.msc`
2. 创建基本任务
3. 触发器: 计算机启动时
4. 操作: 启动程序
   - 程序: `C:\Windows\System32\cmd.exe`
   - 参数: `/c "cd C:\path\to\turing-blog && start-server.bat"`

### 方法2：启动文件夹

1. Win + R → 输入 `shell:startup`
2. 创建 `start-turing-blog.bat` 快捷方式

## 问题排查

### 端口被占用
```powershell
# 查看端口占用
netstat -ano | findstr :5173
netstat -ano | findstr :3001

# 结束进程
taskkill /PID <进程ID> /F
```

### Node.js 未安装
```
下载地址: https://nodejs.org/
选择 Windows Installer (.msi)
安装后重启 PowerShell
```

---

**项目地址**: https://github.com/yuguyue888/turing-blog
